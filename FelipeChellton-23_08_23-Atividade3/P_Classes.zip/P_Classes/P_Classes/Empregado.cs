﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P_Classes
{
    abstract class Empregado
    {
        private int matricula; //Atributos
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;
        private char homeOffice;

        public int Matricula //Propriedade
        {
            get { return matricula; }
            set { matricula = value; }
        }

        public string NomeEmpregado //Propriedade
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }

        public DateTime DataEntradaEmpresa //Propriedade
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }


        public char HomeOffice //Propriedade
        {
            get { return homeOffice; }
            set { homeOffice = value; }
        }
        //metodos
        public string Verificahome()//metodo
        {
            if (homeOffice == 'S')
                return "Empregado trabalha em home office";
            else
                return "Empregado NAO trabalha em home office";
        }


        public virtual int TempoTrabalho()
        {
            //representa um intervalo de tempo
            TimeSpan span = DateTime.Today.Subtract
                (DataEntradaEmpresa);
            return (span.Days);

        }


        public abstract double SalarioBruto();




    }
}