﻿namespace P_Classes
{
    partial class fmrHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioPorHora = new System.Windows.Forms.Label();
            this.lblNHoras = new System.Windows.Forms.Label();
            this.lblDataDeEntradaNaEmpresa = new System.Windows.Forms.Label();
            this.lblDiasDeFérias = new System.Windows.Forms.Label();
            this.btnInstanciarHorario = new System.Windows.Forms.Button();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtHora = new System.Windows.Forms.TextBox();
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtFalta = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(68, 70);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(73, 20);
            this.lblMatricula.TabIndex = 0;
            this.lblMatricula.Text = "Matricula";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(68, 109);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(51, 20);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome";
            // 
            // lblSalarioPorHora
            // 
            this.lblSalarioPorHora.AutoSize = true;
            this.lblSalarioPorHora.Location = new System.Drawing.Point(68, 149);
            this.lblSalarioPorHora.Name = "lblSalarioPorHora";
            this.lblSalarioPorHora.Size = new System.Drawing.Size(124, 20);
            this.lblSalarioPorHora.TabIndex = 2;
            this.lblSalarioPorHora.Text = "Salário por Hora";
            // 
            // lblNHoras
            // 
            this.lblNHoras.AutoSize = true;
            this.lblNHoras.Location = new System.Drawing.Point(68, 189);
            this.lblNHoras.Name = "lblNHoras";
            this.lblNHoras.Size = new System.Drawing.Size(131, 20);
            this.lblNHoras.TabIndex = 3;
            this.lblNHoras.Text = "Número de horas";
            // 
            // lblDataDeEntradaNaEmpresa
            // 
            this.lblDataDeEntradaNaEmpresa.AutoSize = true;
            this.lblDataDeEntradaNaEmpresa.Location = new System.Drawing.Point(68, 228);
            this.lblDataDeEntradaNaEmpresa.Name = "lblDataDeEntradaNaEmpresa";
            this.lblDataDeEntradaNaEmpresa.Size = new System.Drawing.Size(217, 20);
            this.lblDataDeEntradaNaEmpresa.TabIndex = 4;
            this.lblDataDeEntradaNaEmpresa.Text = "Data de Entrada na Empresa";
            // 
            // lblDiasDeFérias
            // 
            this.lblDiasDeFérias.AutoSize = true;
            this.lblDiasDeFérias.Location = new System.Drawing.Point(68, 265);
            this.lblDiasDeFérias.Name = "lblDiasDeFérias";
            this.lblDiasDeFérias.Size = new System.Drawing.Size(111, 20);
            this.lblDiasDeFérias.TabIndex = 5;
            this.lblDiasDeFérias.Text = "Dias de Férias";
            // 
            // btnInstanciarHorario
            // 
            this.btnInstanciarHorario.Location = new System.Drawing.Point(62, 338);
            this.btnInstanciarHorario.Name = "btnInstanciarHorario";
            this.btnInstanciarHorario.Size = new System.Drawing.Size(223, 67);
            this.btnInstanciarHorario.TabIndex = 6;
            this.btnInstanciarHorario.Text = "Instanciar Horário";
            this.btnInstanciarHorario.UseVisualStyleBackColor = true;
            this.btnInstanciarHorario.Click += new System.EventHandler(this.BtnInstanciarHorario_Click);
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(316, 64);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 26);
            this.txtMatricula.TabIndex = 7;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(316, 103);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(197, 26);
            this.txtNome.TabIndex = 8;
            this.txtNome.TextChanged += new System.EventHandler(this.TxtNome_TextChanged);
            // 
            // txtHora
            // 
            this.txtHora.Location = new System.Drawing.Point(316, 183);
            this.txtHora.Name = "txtHora";
            this.txtHora.Size = new System.Drawing.Size(100, 26);
            this.txtHora.TabIndex = 9;
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(316, 222);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(196, 26);
            this.txtData.TabIndex = 10;
            // 
            // txtFalta
            // 
            this.txtFalta.Location = new System.Drawing.Point(316, 259);
            this.txtFalta.Name = "txtFalta";
            this.txtFalta.Size = new System.Drawing.Size(100, 26);
            this.txtFalta.TabIndex = 11;
            this.txtFalta.TextChanged += new System.EventHandler(this.DiasDeFerias_TextChanged);
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(316, 143);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(100, 26);
            this.txtSalario.TabIndex = 12;
            this.txtSalario.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
            // 
            // fmrHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtFalta);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtHora);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.btnInstanciarHorario);
            this.Controls.Add(this.lblDiasDeFérias);
            this.Controls.Add(this.lblDataDeEntradaNaEmpresa);
            this.Controls.Add(this.lblNHoras);
            this.Controls.Add(this.lblSalarioPorHora);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Name = "fmrHorista";
            this.Text = "fmrHorista";
            this.Load += new System.EventHandler(this.FmrHorista_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioPorHora;
        private System.Windows.Forms.Label lblNHoras;
        private System.Windows.Forms.Label lblDataDeEntradaNaEmpresa;
        private System.Windows.Forms.Label lblDiasDeFérias;
        private System.Windows.Forms.Button btnInstanciarHorario;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtHora;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtFalta;
        private System.Windows.Forms.TextBox txtSalario;
    }
}