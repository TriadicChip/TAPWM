﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P_Classes
{
    public partial class fmrHorista : Form
    {
        public fmrHorista()
        {
            InitializeComponent();
        }

        private void FmrHorista_Load(object sender, EventArgs e)
        {

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void DiasDeFerias_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnInstanciarHorario_Click(object sender, EventArgs e)
        {
            
                //Criar o objeto e instanciar o objeto
            Horista ObjHorista = new Horista();

            ObjHorista.NomeEmpregado = txtNome.Text;
            ObjHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            ObjHorista.SalarioHora = Convert.ToDouble(txtSalario.Text);
            ObjHorista.NumeroHora = Convert.ToDouble(txtHora.Text);
            ObjHorista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            ObjHorista.DiasFalta = Convert.ToInt32(txtFalta.Text);

            MessageBox.Show(
                  "Nome: " + ObjHorista.NomeEmpregado + "\n"
                + "Matricula: " + ObjHorista.Matricula + "\n"
                + "Tempo Trabalho: " + ObjHorista.TempoTrabalho().ToString() + "\n "
                + "Salário: " + ObjHorista.SalarioBruto().ToString("N2") + "\n"

            );


        }
    }
}
